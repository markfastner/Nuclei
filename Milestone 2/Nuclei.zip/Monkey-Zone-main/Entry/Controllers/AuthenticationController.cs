﻿using Logic.Authentication.Commands;
using Logic.Authentication.Common;
using Logic.Authentication.Queries;
using Contracts.Authentication;
using Microsoft.AspNetCore.Authorization;

namespace Entry.Controllers
{
    [Route("[controller]/[action]")]
    [AllowAnonymous]        //only controller which avoids authorization because authentication hasn't happened yet
    public class AuthenticationController : ApiController
    {
        private readonly ISender _mediator;
        private readonly IMapper _mapper;

        public AuthenticationController(ISender mediator, IMapper mapper)
        {
            _mediator = mediator;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginRequest request)
        {
            var query = _mapper.Map<LoginQuery>(request);
            var authResult = await _mediator.Send(query);

            //if (authResult.IsError && authResult.FirstError == DomainErrors.Authentication.InvalidCredentials)
            //{
            //    return Problem(
            //        statusCode: StatusCodes.Status401Unauthorized,
            //        title: authResult.FirstError.Description
            //    );
            //}

            return authResult.Match(
                authResult => Ok(_mapper.Map<AuthenticationResponse>(authResult)),
                errors => Problem(errors)
            );
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterRequest request)
        {
            //temp; user EULA
            Console.WriteLine("Are you a robot? (Y/N)");

            if (Console.ReadLine()?.ToLower() == "y") return Ok();

            Console.WriteLine("Do you agree with our terms and policies? (Y/N)");

            if (Console.ReadLine()?.ToLower() == "n") Ok();

            var command = _mapper.Map<RegisterCommand>(request);
            ErrorOr<AuthenticationResult> authResult = await _mediator.Send(command);

            return authResult.Match(
                authResult => Ok(_mapper.Map<AuthenticationResponse>(authResult)),
                errors => Problem(errors)
            );
        }
    }
}