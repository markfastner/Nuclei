﻿namespace Entry.Common.Http
{
    public static class HttpContextItemKeys
    {
        public const string Errors = "errors";
    }
}
