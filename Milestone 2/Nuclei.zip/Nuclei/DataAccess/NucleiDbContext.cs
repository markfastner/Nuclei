﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class NucleiDbContext : DbContext
    {
        public NucleiDbContext(DbContextOptions<NucleiDbContext> options) : base(options)
        {

        }
        public DbSet<User> User { get; set; } = null!;

        public DbSet<LogEntry> LogEntry { get; set; } = null!;
    }
}
