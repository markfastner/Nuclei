﻿
namespace Contracts.Authentication
{
    public record AuthenticationResponse(
        int UserId,
        string FirstName,
        string LastName,
        DateOnly Birthday,
        string Email,
        string Token
    );
}
