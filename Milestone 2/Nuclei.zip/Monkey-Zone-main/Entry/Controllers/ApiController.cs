﻿using Entry.Common.Http;
using Domain.Common.Errors;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Entry.Controllers
{
    [ApiController]
    //[Authorize]
    public class ApiController : ControllerBase
    {
        protected IActionResult Problem(List<Error> errors)
        {
            if (HttpContext is not null)
            {
                HttpContext.Items[HttpContextItemKeys.Errors] = errors;
            }

            if (errors.Count == 1) return Problem(errors.First());      //if single error
            else return ValidationProblem(errors);      //if multiple errors occur
        }

        private IActionResult Problem(Error error)
        {
            var statusCode = (int)error.Type switch
            {
                //ordered by code
                (int)ErrorType.Validation => StatusCodes.Status400BadRequest,
                (int)ErrorType.NotFound => StatusCodes.Status404NotFound,
                (int)ErrorType.Conflict => StatusCodes.Status409Conflict,
                (int)ErrorType.Failure => StatusCodes.Status424FailedDependency,
                CustomErrorTypes.Gone => StatusCodes.Status410Gone,
                _ => StatusCodes.Status500InternalServerError
            };

            return Problem(
                statusCode: statusCode,
                title: error.Description
            );
        }

        private IActionResult ValidationProblem(List<Error> errors)
        {
            ModelStateDictionary modelStateDictionary = new();

            foreach (Error error in errors)
            {
                modelStateDictionary.AddModelError(
                    error.Code,
                    error.Description
                );
            }

            return ValidationProblem(modelStateDictionary);
        }
    }
}
