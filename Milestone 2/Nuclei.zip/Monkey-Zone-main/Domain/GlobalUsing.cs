﻿global using ErrorOr;
