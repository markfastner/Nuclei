﻿using Logic.Common.Interfaces.Authentication;
using Microsoft.AspNetCore.Identity;

namespace Services.Utilities
{
    public class PasswordHasher : IPasswordHasher
    {
        public string Hash(string password) => BCrypt.Net.BCrypt.HashPassword(password);
        public bool Verify(string password, string passwordHashed) => BCrypt.Net.BCrypt.Verify(password, passwordHashed);
    }
}
