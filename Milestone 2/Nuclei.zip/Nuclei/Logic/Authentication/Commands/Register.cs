﻿using FluentValidation;
using Logic.Authentication.Common;
using Logic.Common.Interfaces.Authentication;
using Logic.Common.Interfaces.Persistence;

namespace Logic.Authentication.Commands;

public record RegisterCommand(
    string FirstName,
    string LastName,
    DateTime Birthday,
    string Email,
    string Password
) : IRequest<ErrorOr<AuthenticationResult>>;

public class RegisterCommandHandler : IRequestHandler<RegisterCommand, ErrorOr<AuthenticationResult>>
{
    private readonly IJwtTokenGenerator _jwtTokenGenerator;
    private readonly IPasswordHasher _passwordHasher;
    private readonly IUserRepository _userRepository;

    public RegisterCommandHandler(
        IJwtTokenGenerator jwtTokenGenerator, 
        IUserRepository userRepository,
        IPasswordHasher passwordHasher
    )
    {
        _jwtTokenGenerator = jwtTokenGenerator;
        _passwordHasher = passwordHasher;
        _userRepository = userRepository;
    }

    public async Task<ErrorOr<AuthenticationResult>> Handle(RegisterCommand command, CancellationToken cancellationToken)
    {
        //validate if user doesn't exist
        if (await _userRepository.GetUserByEmailAsync(command.Email) is not null) return DomainErrors.Authentication.InvalidCredentials;
        
        //create user
        var user = new User
        {
            FirstName = command.FirstName,
            LastName = command.LastName,
            Birthday = command.Birthday,
            Email = command.Email,
            Password = command.Password
        };

        //hash password 
        user.Password = _passwordHasher.Hash(command.Password);

        //if inserting to data is unsuccessful
        if (await _userRepository.InsertAsync(user) == false) return DomainErrors.Authentication.Failure;

        //create jwt token
        var token = _jwtTokenGenerator.GenerateToken(user);

        return new AuthenticationResult(
            user,
            token
        ) ; 
    }
}

public class RegisterCommandValidator : AbstractValidator<RegisterCommand>
{
    public RegisterCommandValidator()
    {
        RuleFor(x => x.FirstName)
            .NotEmpty().MaximumLength(50);
        RuleFor(x => x.LastName)
            .NotEmpty().MaximumLength(50);
        RuleFor(x => x.Email)
            .NotEmpty()
            //https://stackoverflow.com/questions/201323/how-can-i-validate-an-email-address-using-a-regular-expression
            .Matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])");
        RuleFor(x => x.Password)
            .NotEmpty().Length(8, 50)
            //https://stackoverflow.com/questions/19605150/regex-for-password-must-contain-at-least-eight-characters-at-least-one-number-a
            .Matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{8,}$");
    }
}