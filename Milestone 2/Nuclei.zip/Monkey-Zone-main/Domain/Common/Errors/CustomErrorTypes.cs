﻿namespace Domain.Common.Errors
{
    public static class CustomErrorTypes
    {
        public const int Gone = 410;
    }
}
