﻿global using Domain.Entities;
global using Microsoft.EntityFrameworkCore;