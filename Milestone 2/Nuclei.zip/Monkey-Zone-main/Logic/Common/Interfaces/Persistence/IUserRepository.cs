﻿using Domain.Entities;

namespace Logic.Common.Interfaces.Persistence
{
    public interface IUserRepository
    {
        Task<User?> GetUserByEmailAsync(string email);
        Task<bool> InsertAsync(User user);
    }
}
