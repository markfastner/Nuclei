﻿using Logic.Common.Interfaces.Persistence;
using DataAccess.Persistence;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using DataAccess.Persistence.Common;
using Logic.Common.Interfaces.Persistence.Common;

namespace DataAccess
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddPersistence(
            this IServiceCollection services,
            ConfigurationManager configuration
        )
        {
            services.AddDbContext<NucleiDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"))
            );

            //dependency injection for persistence repositories
            services.AddTransient<ILoggingRepository, LoggingRepository>();
            services.AddScoped<IUserRepository, UserRepository>();

            return services;
        }
    }
}
