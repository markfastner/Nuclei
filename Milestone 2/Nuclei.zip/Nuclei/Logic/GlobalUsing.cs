﻿global using Domain.Common.Errors;
global using Domain.Entities;
global using ErrorOr;
global using FluentValidation;
global using MediatR;