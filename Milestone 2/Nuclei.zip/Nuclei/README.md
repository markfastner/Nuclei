# private-nuclei
Private repo for Nuclei purposes.

The majority of code was boostrapped by Amichai Martinband's .NET tutorial:
https://github.com/amantinband