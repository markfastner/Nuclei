global using Autofac.Extras.Moq;
global using Domain.Entities;
global using Microsoft.Data.Sqlite;
global using Microsoft.EntityFrameworkCore;
global using Moq;
global using Xunit;