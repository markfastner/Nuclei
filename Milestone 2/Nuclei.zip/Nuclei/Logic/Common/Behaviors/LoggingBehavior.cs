﻿using Microsoft.Extensions.Logging;
using Logic.Common.Interfaces.Persistence.Common;
using Mapster;

namespace Logic.Common.Behaviors;

public class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> 
    where TRequest : IRequest<TResponse>
{
    private readonly ILogger<LoggingBehavior<TRequest, TResponse>> _logger;
    private readonly ILoggingRepository _loggingRepository;

    public LoggingBehavior(
        ILogger<LoggingBehavior<TRequest, TResponse>> logger,
        ILoggingRepository loggingRepository
    )
    {
        _logger = logger;
        _loggingRepository = loggingRepository;
    }

    public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
    {
        string requestName = request.GetType().Name;

        _logger.LogInformation("Calling {requestName}", requestName);

        TResponse response = await next();
        //var adaptedResponse = response.Adapt<TResponse, object>();      //adapts/converts response into a workable object
        
        //log user action to database
        LogEntry log = new()        //create logEntry
        {
            LogLevel = 2,
            Category = "Data",
            Message = response?.ToString() ?? "",
            Operation = requestName
        };

        bool logSuccess = await _loggingRepository.InsertAsync(log);

        if (logSuccess) _logger.LogInformation("Completed {requestName}", requestName);
        else _logger.LogError("Failed {requestName}", requestName);

        return response;
    }
}