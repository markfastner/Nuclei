﻿using ErrorOr;

namespace Domain.Common.Errors
{
    public static partial class DomainErrors
    {
        public static class User
        {

        }
    }
}
