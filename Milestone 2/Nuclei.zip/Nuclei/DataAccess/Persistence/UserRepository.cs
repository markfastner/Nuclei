﻿using Logic.Common.Interfaces.Persistence;

namespace DataAccess.Persistence
{
    public class UserRepository : IUserRepository
    {
        private readonly NucleiDbContext _dbContext;

        public UserRepository(NucleiDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<User?> GetUserByEmailAsync(string email)
        {
            return await _dbContext.User.FirstOrDefaultAsync(e => e.Email == email);
        }

        public async Task<bool> InsertAsync(User user)
        {
            user.UserId = 0;

            _dbContext.User.Add(user);

            return await _dbContext.SaveChangesAsync() > 0;
        }
    }
}
