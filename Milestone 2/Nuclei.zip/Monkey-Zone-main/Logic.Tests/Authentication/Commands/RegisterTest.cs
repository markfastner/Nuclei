using Logic.Authentication.Commands;
using Logic.Authentication.Common;
using Logic.Common.Interfaces.Authentication;
using Logic.Common.Interfaces.Persistence;
using System.Diagnostics;

namespace Logic.Tests.Authentication.Commands
{
    public class RegisterTest : IDisposable
    {
        private readonly AutoMock _autoMock;
        private readonly IMapper _mapper;

        public RegisterTest(IMapper mapper)
        {
            _mapper = mapper;
            _autoMock = AutoMock.GetLoose(config => config.RegisterInstance(_mapper).As<IMapper>());

            _autoMock.Create<IMapper>();
        }

        public void Dispose()
        {
            _autoMock.Dispose();
            GC.SuppressFinalize(this);
        }

        [Fact]
        public async void RegisterTest_ReturnsSuccessCase()
        {
            //assemble
            RegisterCommand request = new(
                Email: "valid@email.com",
                FirstName: "Test",
                LastName: "Test",
                Birthday: DateTime.UtcNow,
                Password: "Test123$"
            );
            
            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.GetUserByEmailAsync(request.Email))
                .ReturnsAsync(It.IsAny<User?>());
            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.InsertAsync(It.IsAny<User>()))
                .ReturnsAsync(true);
            _autoMock.Mock<IPasswordHasher>()
                .Setup(x => x.Hash(request.Password))
                .Returns(request.Password);

            RegisterCommandHandler registerCommandHandler = _autoMock.Create<RegisterCommandHandler>();
            RegisterCommandValidator registerCommandValidator = _autoMock.Create<RegisterCommandValidator>();
            CancellationToken cancellationToken = new();

            //act
            ValidationResult validation = await registerCommandValidator.ValidateAsync(request, cancellationToken);
            ErrorOr<AuthenticationResult> result = await registerCommandHandler.Handle(request, cancellationToken);

            //assert
            Assert.True(validation.IsValid);
            Assert.False(result.IsError);
            Assert.IsType<AuthenticationResult>(result.Value);
            Assert.False(cancellationToken.IsCancellationRequested);
        }

        [Fact]
        public async void RegisterTest_ReturnsFailureCase_1()
        {
            //assemble
            RegisterCommand request = new(
                Email: "invalidemail.com",
                FirstName: "Test",
                LastName: "Test",
                Birthday: DateTime.UtcNow,
                Password: "Test123$"
            );

            RegisterCommandValidator registerCommandValidator = _autoMock.Create<RegisterCommandValidator>();
            CancellationToken cancellationToken = new();

            //act
            ValidationResult validation = await registerCommandValidator.ValidateAsync(request, cancellationToken);

            //assert
            Assert.False(validation.IsValid);
            Assert.Equal("Email", validation.Errors.First().PropertyName);
            Assert.False(cancellationToken.IsCancellationRequested);
        }

        [Fact]
        public async void RegisterTest_ReturnsFailureCase_2()
        {
            //assemble
            RegisterCommand request = new(
                Email: "valid@email.com",
                FirstName: "Test",
                LastName: "Test",
                Birthday: DateTime.UtcNow,
                Password: "Test123$"
            );
            User validUser = _mapper.Map<User>(request);

            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.GetUserByEmailAsync(request.Email))
                .ReturnsAsync(validUser);

            RegisterCommandHandler registerCommandHandler = _autoMock.Create<RegisterCommandHandler>();
            RegisterCommandValidator registerCommandValidator = _autoMock.Create<RegisterCommandValidator>();
            CancellationToken cancellationToken = new();

            //act
            ValidationResult validation = await registerCommandValidator.ValidateAsync(request, cancellationToken);
            ErrorOr<AuthenticationResult> result = await registerCommandHandler.Handle(request, cancellationToken);

            //assert
            Assert.True(validation.IsValid);
            Assert.True(result.IsError);
            Assert.IsType<Error>(result.FirstError);
            Assert.Equal(DomainErrors.Authentication.InvalidCredentials.Code, result.FirstError.Code);
            Assert.False(cancellationToken.IsCancellationRequested);
        }

        [Fact]
        public async void RegisterTest_ReturnsFailureCase_3()
        {
            //assemble
            RegisterCommand request = new(
                Email: "valid@email.com",
                FirstName: "Test",
                LastName: "Test",
                Birthday: DateTime.UtcNow,
                Password: "Test123"
            );

            RegisterCommandValidator registerCommandValidator = _autoMock.Create<RegisterCommandValidator>();
            CancellationToken cancellationToken = new();

            //act
            ValidationResult validation = await registerCommandValidator.ValidateAsync(request, cancellationToken);

            //assert
            Assert.False(validation.IsValid);
            Assert.Equal("Password", validation.Errors.First().PropertyName);
            Assert.False(cancellationToken.IsCancellationRequested);
        }

        [Fact]
        public async void RegisterTest_ReturnsFailureCase_4()
        {
            //assemble
            RegisterCommand request = new(
                Email: "valid@email.com",
                FirstName: "Test",
                LastName: "Test",
                Birthday: DateTime.UtcNow,
                Password: "Test123$"
            );

            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.GetUserByEmailAsync(request.Email))
                .ReturnsAsync(It.IsAny<User?>());
            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.InsertAsync(It.IsAny<User>()))
                .ReturnsAsync(false);
            _autoMock.Mock<IPasswordHasher>()
                .Setup(x => x.Hash(request.Password))
                .Returns(request.Password);

            RegisterCommandHandler registerCommandHandler = _autoMock.Create<RegisterCommandHandler>();
            RegisterCommandValidator registerCommandValidator = _autoMock.Create<RegisterCommandValidator>();
            CancellationToken cancellationToken = new();

            //act
            ValidationResult validation = await registerCommandValidator.ValidateAsync(request, cancellationToken);
            ErrorOr<AuthenticationResult> result = await registerCommandHandler.Handle(request, cancellationToken);

            //assert
            Assert.True(validation.IsValid);
            Assert.True(result.IsError);
            Assert.IsType<Error>(result.FirstError);
            Assert.Equal(DomainErrors.Authentication.Failure.Code, result.FirstError.Code);
            Assert.False(cancellationToken.IsCancellationRequested);
        }

        [Fact]
        public async void RegisterTest_ReturnsFailureCase_5()
        {
            //assemble
            RegisterCommand request = new(
                Email: "valid@email.com",
                FirstName: "Test",
                LastName: "Test",
                Birthday: DateTime.UtcNow,
                Password: "Test123$"
            );

            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.GetUserByEmailAsync(request.Email))
                .ReturnsAsync(It.IsAny<User?>());
            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.InsertAsync(It.IsAny<User>()))
                .ReturnsAsync(true);
            _autoMock.Mock<IPasswordHasher>()
                .Setup(x => x.Hash(request.Password))
                .Returns(request.Password);

            RegisterCommandValidator registerCommandValidator = _autoMock.Create<RegisterCommandValidator>();
            CancellationTokenSource cancellationTokenSource = new();
            CancellationToken cancellationToken = cancellationTokenSource.Token;

            //act
            cancellationTokenSource.Cancel();       //simulates a timeout

            //assert
            Assert.True(cancellationToken.IsCancellationRequested);
            await Assert.ThrowsAsync<OperationCanceledException>(() => registerCommandValidator.ValidateAsync(request, cancellationToken));

        }

        [Fact]
        public async void RegisterTest_ReturnsFailureCase_6()
        {
            //assemble
            Stopwatch stopwatch = new();
            RegisterCommand request = new(
                Email: "valid@email.com",
                FirstName: "Test",
                LastName: "Test",
                Birthday: DateTime.UtcNow,
                Password: "Test123$"
            );

            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.GetUserByEmailAsync(request.Email))
                .ReturnsAsync(It.IsAny<User?>());
            _autoMock.Mock<IUserRepository>()
                .Setup(x => x.InsertAsync(It.IsAny<User>()))
                .ReturnsAsync(true);
            _autoMock.Mock<IPasswordHasher>()
                .Setup(x => x.Hash(request.Password))
                .Returns(request.Password);

            RegisterCommandHandler registerCommandHandler = _autoMock.Create<RegisterCommandHandler>();
            RegisterCommandValidator registerCommandValidator = _autoMock.Create<RegisterCommandValidator>();
            CancellationToken cancellationToken = new();

            //act
            stopwatch.Start();
            Thread.Sleep(5000);

            ValidationResult validation = await registerCommandValidator.ValidateAsync(request, cancellationToken);
            ErrorOr<AuthenticationResult> result = await registerCommandHandler.Handle(request, cancellationToken);
            
            stopwatch.Stop();

            //assert
            Assert.True(validation.IsValid);
            Assert.False(result.IsError);
            Assert.IsType<AuthenticationResult>(result.Value);
            Assert.False(cancellationToken.IsCancellationRequested);
            Assert.True(stopwatch.ElapsedMilliseconds > 5000);
        }
    }
}