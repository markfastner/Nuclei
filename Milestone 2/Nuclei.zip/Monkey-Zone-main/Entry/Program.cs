using Entry;
using DataAccess;
using Logic;
using Services;

var builder = WebApplication.CreateBuilder(args);
{
    builder.Services
        .AddPresentation()
        .AddApplicationLogic()
        .AddPersistence(builder.Configuration)
        .AddInfrastructure(builder.Configuration)
        .ConfigureSwaggerGen(setup =>
        {
            setup.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
            {
                Title = "Nuclei",
                Version = "v1"
            });
        });
}

var app = builder.Build();
{
    app.UseSwagger();
    app.UseSwaggerUI();

    app.UseAuthentication();
    app.UseAuthorization();

    app.UseCors();

    app.UseHttpsRedirection();
    app.MapControllers();
    app.Run();
}